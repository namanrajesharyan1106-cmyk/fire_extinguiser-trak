import React from 'react';
import { Box, Typography, Grid, Card, CardContent } from '@mui/material';


import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ShieldAlert, CheckCircle, Wrench, AlertTriangle } from 'lucide-react';

const Dashboard: React.FC = () => {
  // Using generic mock data for the UI while backend is being wired up
  // In a real scenario, this would come from a dedicated /api/dashboard endpoint
  const stats = [
    { title: 'Total Assets', value: '1,245', icon: <CheckCircle color="#36B37E" size={32} />, color: '#e3fcef' },
    { title: 'Inspections Due', value: '42', icon: <AlertTriangle color="#FFAB00" size={32} />, color: '#fff0b3' },
    { title: 'Open Maintenance', value: '8', icon: <Wrench color="#FF5630" size={32} />, color: '#ffebe6' },
    { title: 'Missing Assets', value: '3', icon: <ShieldAlert color="#FF5630" size={32} />, color: '#ffebe6' },
  ];

  const data = [
    { name: 'Jan', inspections: 400, maintenance: 24 },
    { name: 'Feb', inspections: 300, maintenance: 13 },
    { name: 'Mar', inspections: 200, maintenance: 98 },
    { name: 'Apr', inspections: 278, maintenance: 39 },
    { name: 'May', inspections: 189, maintenance: 48 },
    { name: 'Jun', inspections: 239, maintenance: 38 },
    { name: 'Jul', inspections: 349, maintenance: 43 },
  ];

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 4, fontWeight: 'bold' }}>
        Dashboard Overview
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        {stats.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card sx={{ height: '100%' }}>
              <CardContent sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 600, mb: 1 }}>
                    {stat.title}
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 'bold', color: '#172B4D' }}>
                    {stat.value}
                  </Typography>
                </Box>
                <Box sx={{ p: 1.5, borderRadius: 2, backgroundColor: stat.color }}>
                  {stat.icon}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3, fontWeight: 'bold' }}>
                Inspection vs Maintenance Trends
              </Typography>
              <Box sx={{ height: 350 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} />
                    <YAxis axisLine={false} tickLine={false} />
                    <Tooltip cursor={{ fill: '#F4F5F7' }} />
                    <Bar dataKey="inspections" fill="#0052cc" radius={[4, 4, 0, 0]} name="Inspections" />
                    <Bar dataKey="maintenance" fill="#FFAB00" radius={[4, 4, 0, 0]} name="Maintenance" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 3, fontWeight: 'bold' }}>
                Recent Activities
              </Typography>
              {/* Timeline or list of recent actions would go here */}
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Box key={i} sx={{ display: 'flex', gap: 2, alignItems: 'flex-start' }}>
                    <Box sx={{ mt: 0.5, width: 8, height: 8, borderRadius: '50%', backgroundColor: '#0052cc' }} />
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>Inspection Completed</Typography>
                      <Typography variant="caption" color="text.secondary">Asset FE-00{i} at LOC-0{i} • 2 hours ago</Typography>
                    </Box>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
