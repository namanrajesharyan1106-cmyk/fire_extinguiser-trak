import React, { useState } from 'react';
import { Box, Typography, Card, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, TextField, CircularProgress, MenuItem, Select, InputLabel, FormControl } from '@mui/material';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Edit2, Link as LinkIcon } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import api from '../api/axios';
import { toast } from 'react-toastify';

const assetSchema = z.object({
  asset_id: z.string().min(1, 'Required'),
  serial_number: z.string().min(1, 'Required'),
  asset_type: z.string().min(1, 'Required'),
  capacity: z.string().min(1, 'Required'),
  manufacturer: z.string().min(1, 'Required'),
  manufacturing_date: z.string().min(1, 'Required'),
  refill_date: z.string().min(1, 'Required'),
  expiry_date: z.string().min(1, 'Required'),
});

type AssetForm = z.infer<typeof assetSchema>;

const Assets: React.FC = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedAssetForLink, setSelectedAssetForLink] = useState<string | null>(null);
  const [selectedLocationForLink, setSelectedLocationForLink] = useState<string>('');

  const { data: assets, isLoading, isError } = useQuery({
    queryKey: ['assets'],
    queryFn: async () => {
      const res = await api.get('/assets');
      return res.data;
    }
  });
  
  const { data: locations } = useQuery({
    queryKey: ['locations'],
    queryFn: async () => {
      const res = await api.get('/locations');
      return res.data;
    }
  });

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<AssetForm>({
    resolver: zodResolver(assetSchema)
  });

  const mutation = useMutation({
    mutationFn: async (data: AssetForm) => {
      if (editingId) {
        return api.put(`/assets/${editingId}`, data);
      }
      return api.post('/assets', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      toast.success(`Asset successfully ${editingId ? 'updated' : 'added'}!`);
      handleClose();
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.detail || 'An error occurred');
    }
  });

  const linkMutation = useMutation({
    mutationFn: async () => {
      return api.post(`/assets/${selectedAssetForLink}/link/${selectedLocationForLink}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      queryClient.invalidateQueries({ queryKey: ['locations'] });
      toast.success('Asset linked successfully!');
      handleLinkClose();
    },
    onError: (error: any) => {
      toast.error(error.response?.data?.detail || 'Linking failed');
    }
  });

  const handleOpen = (asset?: any) => {
    if (asset) {
      setEditingId(asset.asset_id);
      Object.keys(asset).forEach((key) => {
        if (key in assetSchema.shape) {
          setValue(key as any, asset[key]);
        }
      });
    } else {
      setEditingId(null);
      reset();
    }
    setOpen(true);
  };
  
  const handleLinkOpen = (asset_id: string) => {
    setSelectedAssetForLink(asset_id);
    setSelectedLocationForLink('');
    setLinkOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    reset();
    setEditingId(null);
  };
  
  const handleLinkClose = () => {
    setLinkOpen(false);
    setSelectedAssetForLink(null);
    setSelectedLocationForLink('');
  };

  const onSubmit = (data: AssetForm) => {
    mutation.mutate(data);
  };
  
  const onLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLocationForLink) return;
    linkMutation.mutate();
  };

  if (isLoading) return <Box display="flex" justifyContent="center" p={5}><CircularProgress /></Box>;
  if (isError) return <Typography color="error">Error loading assets.</Typography>;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight="bold">Assets</Typography>
        <Button variant="contained" startIcon={<Plus size={18} />} onClick={() => handleOpen()}>
          Add Asset
        </Button>
      </Box>

      <Card>
        <TableContainer>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Type / Capacity</TableCell>
                <TableCell>S/N</TableCell>
                <TableCell>Expiry Date</TableCell>
                <TableCell>Current Location</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {assets?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 3 }}>
                    No assets found. Create one to get started.
                  </TableCell>
                </TableRow>
              ) : (
                assets?.map((asset: any) => (
                  <TableRow key={asset.asset_id}>
                    <TableCell>{asset.asset_id}</TableCell>
                    <TableCell>{asset.asset_type} ({asset.capacity})</TableCell>
                    <TableCell>{asset.serial_number}</TableCell>
                    <TableCell>{asset.expiry_date}</TableCell>
                    <TableCell>
                      {asset.current_location_id ? (
                        <Typography color="primary" fontWeight="bold">{asset.current_location_id}</Typography>
                      ) : (
                        <Typography color="error.main">Unassigned</Typography>
                      )}
                    </TableCell>
                    <TableCell align="right">
                      <IconButton size="small" color="primary" onClick={() => handleLinkOpen(asset.asset_id)}><LinkIcon size={18} /></IconButton>
                      <IconButton size="small" color="secondary" onClick={() => handleOpen(asset)}><Edit2 size={18} /></IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <form onSubmit={handleSubmit(onSubmit)}>
          <DialogTitle>{editingId ? 'Edit Asset' : 'Add Asset'}</DialogTitle>
          <DialogContent dividers sx={{ display: 'grid', gap: 2 }}>
            <TextField label="Asset ID" {...register('asset_id')} error={!!errors.asset_id} helperText={errors.asset_id?.message} disabled={!!editingId} />
            <TextField label="Serial Number" {...register('serial_number')} error={!!errors.serial_number} helperText={errors.serial_number?.message} />
            <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
              <TextField label="Asset Type (e.g. CO2)" {...register('asset_type')} error={!!errors.asset_type} helperText={errors.asset_type?.message} />
              <TextField label="Capacity (e.g. 5KG)" {...register('capacity')} error={!!errors.capacity} helperText={errors.capacity?.message} />
            </Box>
            <TextField label="Manufacturer" {...register('manufacturer')} error={!!errors.manufacturer} helperText={errors.manufacturer?.message} />
            <TextField type="date" label="Manufacturing Date" InputLabelProps={{ shrink: true }} {...register('manufacturing_date')} error={!!errors.manufacturing_date} helperText={errors.manufacturing_date?.message} />
            <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
              <TextField type="date" label="Refill Date" InputLabelProps={{ shrink: true }} {...register('refill_date')} error={!!errors.refill_date} helperText={errors.refill_date?.message} />
              <TextField type="date" label="Expiry Date" InputLabelProps={{ shrink: true }} {...register('expiry_date')} error={!!errors.expiry_date} helperText={errors.expiry_date?.message} />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Cancel</Button>
            <Button type="submit" variant="contained" disabled={mutation.isPending}>
              {mutation.isPending ? 'Saving...' : 'Save Asset'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
      
      <Dialog open={linkOpen} onClose={handleLinkClose} maxWidth="xs" fullWidth>
        <form onSubmit={onLinkSubmit}>
          <DialogTitle>Link Asset to Location</DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2" sx={{ mb: 2 }}>
              Select a location to assign Asset <strong>{selectedAssetForLink}</strong> to. Any existing asset at that location will be automatically unlinked.
            </Typography>
            <FormControl fullWidth>
              <InputLabel>Location</InputLabel>
              <Select
                value={selectedLocationForLink}
                label="Location"
                onChange={(e) => setSelectedLocationForLink(e.target.value)}
              >
                {locations?.map((loc: any) => (
                  <MenuItem key={loc.location_id} value={loc.location_id}>
                    {loc.location_name} ({loc.location_id})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleLinkClose}>Cancel</Button>
            <Button type="submit" variant="contained" disabled={linkMutation.isPending || !selectedLocationForLink}>
              {linkMutation.isPending ? 'Linking...' : 'Link Asset'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};

export default Assets;
