import React from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Box,
  Avatar,
  InputBase,
  Badge,
} from '@mui/material';
import { Search, Bell, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const navigate = useNavigate();

  // Safely read user from localStorage
  const getUser = () => {
    try {
      const storedUser = localStorage.getItem('user');

      if (
        !storedUser ||
        storedUser === 'undefined' ||
        storedUser === 'null'
      ) {
        return {};
      }

      return JSON.parse(storedUser);
    } catch (error) {
      console.error('Invalid user data in localStorage:', error);
      localStorage.removeItem('user');
      return {};
    }
  };

  const user: any = getUser();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <AppBar
      position="fixed"
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: '#ffffff',
        color: '#172B4D',
        boxShadow: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
      }}
    >
      <Toolbar>
        <Box
          sx={{
            width: 260,
            display: 'flex',
            alignItems: 'center',
          }}
        />

        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            backgroundColor: '#F4F5F7',
            borderRadius: 1,
            px: 2,
            py: 0.5,
            flexGrow: 1,
            maxWidth: 400,
            ml: 2,
          }}
        >
          <Search size={20} color="#5E6C84" />

          <InputBase
            placeholder="Search assets, locations, tickets..."
            sx={{ ml: 1, flex: 1 }}
          />
        </Box>

        <Box sx={{ flexGrow: 1 }} />

        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 2,
          }}
        >
          <IconButton>
            <Badge badgeContent={3} color="error">
              <Bell size={20} />
            </Badge>
          </IconButton>

          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <Avatar
              sx={{
                width: 32,
                height: 32,
                bgcolor: '#0052cc',
              }}
            >
              {user?.name?.charAt?.(0) || 'U'}
            </Avatar>

            <Typography
              variant="body2"
              sx={{ fontWeight: 500 }}
            >
              {user?.name || 'User'}
            </Typography>
          </Box>

          <IconButton
            onClick={handleLogout}
            color="error"
            title="Logout"
          >
            <LogOut size={20} />
          </IconButton>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;