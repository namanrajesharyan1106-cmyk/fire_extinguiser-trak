import os
# pyrefly: ignore [missing-import]
import bcrypt
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Date, Text, Boolean, Table
from sqlalchemy.orm import relationship
from .database import Base

# Many-to-many relationship for Roles and Permissions
role_permissions = Table(
    "role_permissions",
    Base.metadata,
    Column("role_id", Integer, ForeignKey("roles.id"), primary_key=True),
    Column("permission_id", Integer, ForeignKey("permissions.id"), primary_key=True)
)

class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String, nullable=True)
    
    permissions = relationship("Permission", secondary=role_permissions, back_populates="roles")

class Permission(Base):
    __tablename__ = "permissions"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # e.g., "view_dashboard"
    description = Column(String, nullable=True)

    roles = relationship("Role", secondary=role_permissions, back_populates="permissions")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String, unique=True, index=True)
    name = Column(String)
    email = Column(String, unique=True, index=True)
    password_hash = Column(String)
    department = Column(String)
    plant = Column(String, nullable=True)
    role = Column(String) # We can keep string reference to Role.name for backward compatibility
    status = Column(String, default="Active")
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # New Security Fields
    is_first_login = Column(Boolean, default=True)
    failed_login_attempts = Column(Integer, default=0)
    last_failed_login = Column(DateTime, nullable=True)
    last_login_ip = Column(String, nullable=True)
    last_login_device = Column(String, nullable=True)
    last_login = Column(DateTime, nullable=True)
    locked_until = Column(DateTime, nullable=True)

    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")
    password_history = relationship("PasswordHistory", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user", cascade="all, delete-orphan")

class RefreshToken(Base):
    __tablename__ = "refresh_tokens"
    id = Column(Integer, primary_key=True, index=True)
    token_hash = Column(String, unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    device_name = Column(String, nullable=True)
    ip_address = Column(String, nullable=True)
    is_revoked = Column(Boolean, default=False)
    revoked_at = Column(DateTime, nullable=True)
    
    user = relationship("User", back_populates="refresh_tokens")

class PasswordHistory(Base):
    __tablename__ = "password_history"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    password_hash = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="password_history")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String)
    table_name = Column(String, nullable=True)
    record_id = Column(String, nullable=True)
    old_values = Column(Text, nullable=True)
    new_values = Column(Text, nullable=True)
    ip_address = Column(String, nullable=True)
    device = Column(String, nullable=True)
    browser = Column(String, nullable=True)
    status = Column(String, nullable=True) # Success or Failure
    timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="audit_logs")

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    type = Column(String)
    message = Column(String)
    is_read = Column(Boolean, default=False)
    related_id = Column(String, nullable=True)
    related_type = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")

class Plant(Base):
    __tablename__ = "plants"
    id = Column(Integer, primary_key=True, index=True)
    plant_code = Column(String, unique=True, index=True)
    plant_name = Column(String)
    address = Column(String, nullable=True)
    contact = Column(String, nullable=True)
    status = Column(String, default="Active")
    created_at = Column(DateTime, default=datetime.utcnow)

class Department(Base):
    __tablename__ = "departments"
    id = Column(Integer, primary_key=True, index=True)
    dept_code = Column(String, unique=True, index=True)
    dept_name = Column(String)
    plant_id = Column(Integer, ForeignKey("plants.id"), nullable=True)
    head_name = Column(String, nullable=True)
    status = Column(String, default="Active")
    created_at = Column(DateTime, default=datetime.utcnow)

    plant_ref = relationship("Plant")

class Attachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True, index=True)
    related_id = Column(String, index=True)
    related_type = Column(String, index=True)
    file_path = Column(String)
    file_type = Column(String, nullable=True)
    label = Column(String, nullable=True)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    uploader = relationship("User")

class SystemConfig(Base):
    __tablename__ = "system_config"
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String, unique=True, index=True)
    value = Column(String, nullable=True)
    description = Column(String, nullable=True)

class Location(Base):
    __tablename__ = "locations"
    location_id = Column(String, primary_key=True, index=True)
    location_code = Column(String, unique=True, index=True, nullable=True)
    location_name = Column(String)
    area = Column(String)
    department = Column(String)
    building = Column(String)
    floor = Column(String)
    machine = Column(String, nullable=True)
    required_asset_type = Column(String)
    required_capacity = Column(String)
    risk_category = Column(String, default="Medium")
    qr_code = Column(String)
    current_asset_id = Column(String, ForeignKey("assets.asset_id"), nullable=True)
    status = Column(String, default="Active")
    inspection_frequency = Column(Integer, default=30)
    last_inspection_date = Column(DateTime, nullable=True)
    gps_lat = Column(Float, nullable=True)
    gps_lng = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    current_asset = relationship("Asset", foreign_keys=[current_asset_id])
    inspections = relationship("Inspection", back_populates="location")
    maintenance_records = relationship("Maintenance", back_populates="location")

class Asset(Base):
    __tablename__ = "assets"
    asset_id = Column(String, primary_key=True, index=True)
    serial_number = Column(String, unique=True, index=True)
    asset_type = Column(String)
    capacity = Column(String)
    manufacturer = Column(String)
    manufacturing_date = Column(Date)
    refill_date = Column(Date)
    expiry_date = Column(Date)
    inspection_frequency = Column(Integer, default=30)
    amc_due_date = Column(Date, nullable=True)
    barcode = Column(String, nullable=True)
    remarks = Column(Text, nullable=True)
    photo = Column(String, nullable=True)
    current_location_id = Column(String, ForeignKey("locations.location_id"), nullable=True)
    status = Column(String, default="Active")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    current_location = relationship("Location", foreign_keys=[current_location_id])
    history_records = relationship("AssetHistory", back_populates="asset")
    inspections = relationship("Inspection", back_populates="asset")
    maintenance_records = relationship("Maintenance", back_populates="asset")

class AssetHistory(Base):
    __tablename__ = "asset_history"
    id = Column(Integer, primary_key=True, index=True)
    asset_id = Column(String, ForeignKey("assets.asset_id"))
    old_location = Column(String, nullable=True)
    new_location = Column(String, nullable=True)
    movement_type = Column(String, nullable=True)
    movement_reason = Column(String)
    approval_by = Column(String, nullable=True)
    comments = Column(Text, nullable=True)
    movement_date = Column(DateTime, default=datetime.utcnow)
    changed_by = Column(String)

    asset = relationship("Asset", back_populates="history_records")

class Inspection(Base):
    __tablename__ = "inspection"
    inspection_id = Column(Integer, primary_key=True, index=True)
    location_id = Column(String, ForeignKey("locations.location_id"))
    asset_id = Column(String, ForeignKey("assets.asset_id"))
    inspector = Column(String)
    inspector_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    inspection_date = Column(DateTime, default=datetime.utcnow)
    pressure = Column(String)
    seal = Column(String)
    hose = Column(String)
    pin = Column(String)
    gauge = Column(String)
    nozzle = Column(String, nullable=True)
    mounting = Column(String)
    visibility = Column(String)
    accessibility = Column(String)
    safety_tag = Column(String, nullable=True)
    cylinder_damage = Column(String, nullable=True)
    remarks = Column(Text, nullable=True)
    photo = Column(String, nullable=True)
    overall_status = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    location = relationship("Location", back_populates="inspections")
    asset = relationship("Asset", back_populates="inspections")

class Maintenance(Base):
    __tablename__ = "maintenance"
    maintenance_id = Column(Integer, primary_key=True, index=True)
    asset_id = Column(String, ForeignKey("assets.asset_id"))
    location_id = Column(String, ForeignKey("locations.location_id"))
    issue = Column(Text)
    priority = Column(String)
    assigned_to = Column(String, nullable=True)
    technician_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    verified_by = Column(String, nullable=True)
    status = Column(String, default="Open")
    opened_date = Column(DateTime, default=datetime.utcnow)
    completion_date = Column(DateTime, nullable=True)
    closed_date = Column(DateTime, nullable=True)
    inspection_id = Column(Integer, ForeignKey("inspection.inspection_id"), nullable=True)
    remarks = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    asset = relationship("Asset", back_populates="maintenance_records")
    location = relationship("Location", back_populates="maintenance_records")

