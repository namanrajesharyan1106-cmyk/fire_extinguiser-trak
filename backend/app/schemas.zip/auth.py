"""
Authentication utilities and dependency factories.
"""
from typing import List
from jose import JWTError, jwt
from fastapi.security import OAuth2PasswordBearer
from fastapi import Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from . import models, database
from .config import settings
from .logger import logger
from .services.user_service import check_account_status
from .services.rbac_service import role_has_permission
from .services.auth_service import verify_refresh_token
from .constants import ROLES, PERMISSIONS

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")

# ─── Current User Dependency ──────────────────────────────────────────────────
def get_current_user(
    request: Request,
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(database.get_db)
) -> models.User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id_str: str = payload.get("sub")
        token_type: str = payload.get("type", "access")
        
        # In case the older token format uses email for sub, we handle it or reject it
        if user_id_str is None or token_type != "access":
            raise credentials_exception
            
    except JWTError:
        raise credentials_exception

    try:
        user_id = int(user_id_str)
        user = db.query(models.User).filter(models.User.id == user_id).first()
    except ValueError:
        # Backward compatibility if email was used
        user = db.query(models.User).filter(models.User.email == user_id_str).first()
        
    if user is None:
        raise credentials_exception
        
    # Security checks: Active, not locked out
    check_account_status(user)
    
    return user


# ─── RBAC Dependency Factory ──────────────────────────────────────────────────
def require_permission(permission: str):
    """
    Returns a FastAPI dependency that checks if the current user has
    the specified permission based on their role stored in DB.
    """
    def checker(current_user: models.User = Depends(get_current_user), db: Session = Depends(database.get_db)):
        if not role_has_permission(db, current_user.role, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission denied. Required: '{permission}'. Your role: '{current_user.role}'."
            )
        return current_user
    return checker


def require_roles(allowed_roles: List[str]):
    """
    Returns a FastAPI dependency that checks if the current user has one of the allowed roles.
    """
    def checker(current_user: models.User = Depends(get_current_user)):
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access restricted. Allowed roles: {allowed_roles}."
            )
        return current_user
    return checker


# ─── Initialization & Default Admin ───────────────────────────────────────────
def _seed_roles_and_permissions(db: Session):
    """Seeds the DB with Roles and Permissions from constants if empty."""
    # Check if roles exist
    if db.query(models.Role).first():
        return
        
    logger.info("[STARTUP] Seeding Roles and Permissions...")
    
    role_objects = {}
    for r_name in ROLES:
        r = models.Role(name=r_name)
        db.add(r)
        role_objects[r_name] = r
        
    db.commit()
    
    for p_name, allowed_roles in PERMISSIONS.items():
        p = models.Permission(name=p_name)
        db.add(p)
        for r_name in allowed_roles:
            if r_name in role_objects:
                role_objects[r_name].permissions.append(p)
                
    db.commit()
    logger.info("[STARTUP] Seeded Roles and Permissions successfully.")

def create_default_admin(db: Session) -> None:
    """
    Called at application startup.
    Seeds roles/permissions and creates the default ADMIN user if no ADMIN exists.
    """
    _seed_roles_and_permissions(db)
    
    existing_admin = db.query(models.User).filter(
        models.User.role == "ADMIN"
    ).first()

    if existing_admin:
        return  # At least one admin exists

    existing_email = db.query(models.User).filter(
        models.User.email == settings.DEFAULT_ADMIN_EMAIL
    ).first()

    if existing_email:
        # Upgrade existing user to ADMIN
        existing_email.role = "ADMIN"
        existing_email.is_first_login = False
        existing_email.status = "Active"
        existing_email.locked_until = None
        existing_email.failed_login_attempts = 0
        db.commit()
        logger.info(f"[STARTUP] Upgraded existing user {settings.DEFAULT_ADMIN_EMAIL} to ADMIN")
        return

    from .services.auth_service import get_password_hash
    admin_user = models.User(
        employee_id=settings.DEFAULT_ADMIN_EMPLOYEE_ID,
        name=settings.DEFAULT_ADMIN_NAME,
        email=settings.DEFAULT_ADMIN_EMAIL,
        password_hash=get_password_hash(settings.DEFAULT_ADMIN_PASSWORD),
        department=settings.DEFAULT_ADMIN_DEPARTMENT,
        role=settings.DEFAULT_ADMIN_ROLE,
        status="Active",
        is_first_login=False,
        plant=settings.DEFAULT_ADMIN_PLANT,
    )
    db.add(admin_user)
    db.commit()
    logger.info(f"[STARTUP] Default admin created: {settings.DEFAULT_ADMIN_EMAIL}")

