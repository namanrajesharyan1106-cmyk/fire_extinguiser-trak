"""
Pydantic v2 compatible schemas for the Fire Safety Asset Management System.
"""
from pydantic import BaseModel, EmailStr, field_validator, ConfigDict
from typing import Optional, List, Any, Dict, TypeVar, Generic
from datetime import datetime, date

T = TypeVar("T")

class APIResponse(BaseModel, Generic[T]):
    success: bool
    message: str
    data: Optional[T] = None
    errors: Optional[Any] = None



# ─── Auth / User Schemas ──────────────────────────────────────────────────────
class UserBase(BaseModel):
    employee_id: str
    name: str
    email: str
    department: Optional[str] = None
    role: str = "VIEWER"
    status: Optional[str] = "Active"
    phone: Optional[str] = None
    plant: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    role: Optional[str] = None
    status: Optional[str] = None
    phone: Optional[str] = None
    plant: Optional[str] = None

class UserResponse(UserBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_first_login: Optional[bool] = True
    last_login: Optional[datetime] = None
    last_login_ip: Optional[str] = None
    last_login_device: Optional[str] = None
    failed_login_attempts: Optional[int] = 0
    locked_until: Optional[datetime] = None
    created_at: datetime

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    user: UserResponse

class TokenRefresh(BaseModel):
    refresh_token: str

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class ResetPasswordRequest(BaseModel):
    new_password: str

class SessionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_name: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: datetime
    expires_at: datetime
    is_revoked: bool



# ─── Plant Schemas ────────────────────────────────────────────────────────────
class PlantBase(BaseModel):
    plant_code: str
    plant_name: str
    address: Optional[str] = None
    contact: Optional[str] = None
    status: Optional[str] = "Active"

class PlantCreate(PlantBase):
    pass

class PlantUpdate(BaseModel):
    plant_name: Optional[str] = None
    address: Optional[str] = None
    contact: Optional[str] = None
    status: Optional[str] = None

class PlantResponse(PlantBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


# ─── Department Schemas ───────────────────────────────────────────────────────
class DepartmentBase(BaseModel):
    dept_code: str
    dept_name: str
    plant_id: Optional[int] = None
    head_name: Optional[str] = None
    status: Optional[str] = "Active"

class DepartmentCreate(DepartmentBase):
    pass

class DepartmentUpdate(BaseModel):
    dept_name: Optional[str] = None
    plant_id: Optional[int] = None
    head_name: Optional[str] = None
    status: Optional[str] = None

class DepartmentResponse(DepartmentBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime


# ─── Location Schemas ─────────────────────────────────────────────────────────
class LocationBase(BaseModel):
    location_id: str
    location_code: Optional[str] = None
    location_name: str
    plant: Optional[str] = None
    area: Optional[str] = None
    department: Optional[str] = None
    building: Optional[str] = None
    floor: Optional[str] = None
    machine: Optional[str] = None
    required_asset_type: Optional[str] = None
    required_capacity: Optional[str] = None
    risk_category: Optional[str] = "Medium"
    qr_code: Optional[str] = None
    status: Optional[str] = "Active"
    inspection_frequency: Optional[int] = 30
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None

class LocationCreate(LocationBase):
    pass

class LocationUpdate(BaseModel):
    location_code: Optional[str] = None
    location_name: Optional[str] = None
    plant: Optional[str] = None
    area: Optional[str] = None
    department: Optional[str] = None
    building: Optional[str] = None
    floor: Optional[str] = None
    machine: Optional[str] = None
    required_asset_type: Optional[str] = None
    required_capacity: Optional[str] = None
    risk_category: Optional[str] = None
    status: Optional[str] = None
    inspection_frequency: Optional[int] = None
    gps_lat: Optional[float] = None
    gps_lng: Optional[float] = None

class LocationResponse(LocationBase):
    model_config = ConfigDict(from_attributes=True)
    current_asset_id: Optional[str] = None
    qr_image_path: Optional[str] = None
    last_inspection_date: Optional[datetime] = None
    created_at: Optional[datetime] = None


# ─── Asset Schemas ────────────────────────────────────────────────────────────
class AssetBase(BaseModel):
    asset_id: str
    serial_number: str
    asset_type: str
    capacity: Optional[str] = None
    manufacturer: Optional[str] = None
    manufacturing_date: Optional[date] = None
    refill_date: Optional[date] = None
    expiry_date: Optional[date] = None
    inspection_frequency: Optional[int] = 30
    amc_due_date: Optional[date] = None
    barcode: Optional[str] = None
    remarks: Optional[str] = None
    status: Optional[str] = "Active"

class AssetCreate(AssetBase):
    pass

class AssetUpdate(BaseModel):
    serial_number: Optional[str] = None
    asset_type: Optional[str] = None
    capacity: Optional[str] = None
    manufacturer: Optional[str] = None
    manufacturing_date: Optional[date] = None
    refill_date: Optional[date] = None
    expiry_date: Optional[date] = None
    inspection_frequency: Optional[int] = None
    amc_due_date: Optional[date] = None
    barcode: Optional[str] = None
    remarks: Optional[str] = None
    status: Optional[str] = None

class AssetResponse(AssetBase):
    model_config = ConfigDict(from_attributes=True)
    current_location_id: Optional[str] = None
    photo: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


# ─── Asset History Schemas ────────────────────────────────────────────────────
class AssetHistoryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    asset_id: str
    old_location: Optional[str] = None
    new_location: Optional[str] = None
    movement_type: Optional[str] = None
    movement_reason: Optional[str] = None
    approval_by: Optional[str] = None
    comments: Optional[str] = None
    movement_date: datetime
    changed_by: Optional[str] = None

class AssetAssignRequest(BaseModel):
    movement_reason: Optional[str] = "Assigned to location"
    movement_type: Optional[str] = "Assigned"
    comments: Optional[str] = None
    force: Optional[bool] = False   # override warnings


# ─── Inspection Schemas ───────────────────────────────────────────────────────
class InspectionBase(BaseModel):
    location_id: str
    asset_id: Optional[str] = None
    inspector: Optional[str] = None
    pressure: Optional[str] = None
    seal: Optional[str] = None
    pin: Optional[str] = None
    gauge: Optional[str] = None
    hose: Optional[str] = None
    nozzle: Optional[str] = None
    visibility: Optional[str] = None
    accessibility: Optional[str] = None
    mounting: Optional[str] = None
    safety_tag: Optional[str] = None
    cylinder_damage: Optional[str] = None
    remarks: Optional[str] = None

class InspectionCreate(InspectionBase):
    # overall_status is NOT accepted from client — auto-calculated
    pass

class InspectionResponse(InspectionBase):
    model_config = ConfigDict(from_attributes=True)
    inspection_id: int
    overall_status: Optional[str] = None
    inspection_date: datetime
    photo: Optional[str] = None
    created_at: Optional[datetime] = None


# ─── Maintenance Schemas ──────────────────────────────────────────────────────
class MaintenanceBase(BaseModel):
    asset_id: Optional[str] = None
    location_id: Optional[str] = None
    issue: Optional[str] = None
    priority: Optional[str] = "Medium"
    assigned_to: Optional[str] = None
    remarks: Optional[str] = None
    source: Optional[str] = "Manual"

class MaintenanceCreate(MaintenanceBase):
    pass

class MaintenanceUpdate(BaseModel):
    issue: Optional[str] = None
    priority: Optional[str] = None
    assigned_to: Optional[str] = None
    technician_id: Optional[int] = None
    remarks: Optional[str] = None

class MaintenanceStatusUpdate(BaseModel):
    new_status: str
    remarks: Optional[str] = None
    technician_id: Optional[int] = None
    verified_by: Optional[str] = None

class MaintenanceResponse(MaintenanceBase):
    model_config = ConfigDict(from_attributes=True)
    maintenance_id: int
    status: str
    technician_id: Optional[int] = None
    verified_by: Optional[str] = None
    opened_date: datetime
    completion_date: Optional[datetime] = None
    closed_date: Optional[datetime] = None
    inspection_id: Optional[int] = None
    created_at: Optional[datetime] = None


# ─── Attachment Schemas ───────────────────────────────────────────────────────
class AttachmentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    related_id: str
    related_type: str
    file_path: str
    file_type: Optional[str] = None
    label: Optional[str] = None
    created_at: datetime


# ─── Notification Schemas ─────────────────────────────────────────────────────
class NotificationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    type: str
    message: str
    is_read: bool
    related_id: Optional[str] = None
    related_type: Optional[str] = None
    created_at: datetime


# ─── Audit Log Schemas ────────────────────────────────────────────────────────
class AuditLogResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: Optional[int] = None
    action: str
    table_name: Optional[str] = None
    record_id: Optional[str] = None
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    ip_address: Optional[str] = None
    device: Optional[str] = None
    browser: Optional[str] = None
    status: Optional[str] = None
    timestamp: datetime


# ─── Dashboard Schemas ────────────────────────────────────────────────────────
class DashboardStats(BaseModel):
    total_locations: int
    total_assets: int
    installed_assets: int
    unassigned_assets: int
    inspection_due_today: int
    inspection_completed_today: int
    open_maintenance: int
    expired_assets: int
    refill_due: int
    compliance_percent: float
    overdue_inspections: int

class MonthlyTrendItem(BaseModel):
    month: str
    inspections: int
    maintenance: int
    passed: int
    failed: int

class DepartmentStatsItem(BaseModel):
    department: str
    total_locations: int
    installed: int
    compliance: float

class RiskStatsItem(BaseModel):
    risk_category: str
    count: int


# ─── Search Schemas ───────────────────────────────────────────────────────────
class SearchResult(BaseModel):
    type: str         # "asset" | "location" | "inspection" | "maintenance" | "user"
    id: str
    title: str
    subtitle: Optional[str] = None
    status: Optional[str] = None
    url: Optional[str] = None


# ─── System Config Schemas ────────────────────────────────────────────────────
class SystemConfigResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    key: str
    value: Optional[str] = None
    description: Optional[str] = None

class SystemConfigUpdate(BaseModel):
    value: str
