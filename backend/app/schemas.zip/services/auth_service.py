import secrets
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from fastapi import Request

from ..config import settings
from ..models import RefreshToken, User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

def create_refresh_token(db: Session, user_id: int, request: Request = None) -> str:
    raw_token = secrets.token_urlsafe(32)
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    
    # Capture request metadata if available
    ip_address = None
    device_name = None
    if request:
        ip_address = request.client.host
        device_name = request.headers.get("user-agent", "Unknown Device")
        
    db_token = RefreshToken(
        token_hash=get_password_hash(raw_token),
        user_id=user_id,
        expires_at=expire,
        ip_address=ip_address,
        device_name=device_name
    )
    db.add(db_token)
    db.commit()
    db.refresh(db_token)
    
    # We embed the db_token id in the JWT for easy lookup
    to_encode = {"sub": str(user_id), "type": "refresh", "jti": db_token.id, "exp": expire}
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    
    return encoded_jwt

def verify_refresh_token(db: Session, token: str) -> Optional[RefreshToken]:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        jti: int = payload.get("jti")
        
        if user_id is None or token_type != "refresh" or jti is None:
            return None
            
        db_token = db.query(RefreshToken).filter(RefreshToken.id == jti).first()
        if not db_token:
            return None
            
        if db_token.is_revoked or db_token.expires_at < datetime.utcnow():
            return None
            
        return db_token
    except JWTError:
        return None

def revoke_refresh_token(db: Session, token_id: int):
    db_token = db.query(RefreshToken).filter(RefreshToken.id == token_id).first()
    if db_token and not db_token.is_revoked:
        db_token.is_revoked = True
        db_token.revoked_at = datetime.utcnow()
        db.commit()

def revoke_all_user_tokens(db: Session, user_id: int):
    db.query(RefreshToken).filter(
        RefreshToken.user_id == user_id, 
        RefreshToken.is_revoked == False
    ).update({"is_revoked": True, "revoked_at": datetime.utcnow()})
    db.commit()
