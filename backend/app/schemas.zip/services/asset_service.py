"""
Asset Service — business logic for asset assignment validation.
"""
from datetime import datetime, date
from typing import Optional, Tuple, List
from sqlalchemy.orm import Session
from .. import models
from ..utils import is_asset_expired, is_refill_overdue


def validate_asset_assignment(
    db: Session,
    asset_id: str,
    location_id: str,
    force: bool = False
) -> Tuple[bool, List[str], List[str]]:
    """
    Validate whether an asset can be assigned to a location.

    Returns:
        (can_assign: bool, errors: List[str], warnings: List[str])
        - errors are blocking (cannot assign without force)
        - warnings are informational only
    """
    errors: List[str] = []
    warnings: List[str] = []

    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    location = db.query(models.Location).filter(models.Location.location_id == location_id).first()

    if not asset:
        return False, [f"Asset '{asset_id}' not found."], []
    if not location:
        return False, [f"Location '{location_id}' not found."], []

    # ── Error checks (blocking) ────────────────────────────────────────────────
    # 1. Asset already assigned to a different location
    if asset.current_location_id and asset.current_location_id != location_id:
        errors.append(
            f"Asset '{asset_id}' is currently assigned to location '{asset.current_location_id}'. "
            f"Unlink it first or use force."
        )

    # 2. Asset is expired
    if is_asset_expired(asset):
        errors.append(
            f"Asset '{asset_id}' has expired on {asset.expiry_date}. "
            f"Expired assets cannot be assigned to active locations."
        )

    # 3. Asset is under maintenance (open ticket exists)
    open_ticket = db.query(models.Maintenance).filter(
        models.Maintenance.asset_id == asset_id,
        models.Maintenance.status.notin_(["Closed", "Verified"])
    ).first()
    if open_ticket:
        errors.append(
            f"Asset '{asset_id}' has an open maintenance ticket "
            f"(#{open_ticket.maintenance_id}, Priority: {open_ticket.priority}). "
            f"Close the ticket before assigning."
        )

    # 4. Type mismatch
    if (location.required_asset_type and asset.asset_type and
            location.required_asset_type.lower() != asset.asset_type.lower()):
        errors.append(
            f"Type mismatch: Location requires '{location.required_asset_type}' "
            f"but asset is '{asset.asset_type}'."
        )

    # 5. Capacity mismatch
    if (location.required_capacity and asset.capacity and
            location.required_capacity.lower() != asset.capacity.lower()):
        errors.append(
            f"Capacity mismatch: Location requires '{location.required_capacity}' "
            f"but asset capacity is '{asset.capacity}'."
        )

    # ── Warning checks (non-blocking) ─────────────────────────────────────────
    # 6. Refill overdue
    if is_refill_overdue(asset):
        warnings.append(
            f"Asset '{asset_id}' refill is overdue (last refill: {asset.refill_date}). "
            f"Schedule a refill soon."
        )

    # 7. Location already has an asset (will be displaced)
    if location.current_asset_id and location.current_asset_id != asset_id:
        warnings.append(
            f"Location '{location_id}' currently has asset '{location.current_asset_id}'. "
            f"It will be unlinked automatically."
        )

    # 8. Inspection overdue warning
    if location.last_inspection_date and location.inspection_frequency:
        from datetime import timedelta
        next_due = location.last_inspection_date + timedelta(days=location.inspection_frequency)
        if datetime.utcnow() > next_due:
            warnings.append(
                f"Location '{location_id}' has an overdue inspection (last: {location.last_inspection_date.date()})."
            )

    # If there are blocking errors and force is False, cannot assign
    if errors and not force:
        return False, errors, warnings

    return True, errors, warnings


def perform_asset_assignment(
    db: Session,
    asset_id: str,
    location_id: str,
    changed_by: str,
    movement_type: str = "Assigned",
    movement_reason: str = "Assigned to location",
    comments: Optional[str] = None,
) -> dict:
    """
    Perform the actual asset assignment after validation.
    Creates history records and updates both asset and location.
    """
    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    location = db.query(models.Location).filter(models.Location.location_id == location_id).first()

    old_location_id = asset.current_location_id

    # Unlink existing asset from location if different
    if location.current_asset_id and location.current_asset_id != asset_id:
        old_asset = db.query(models.Asset).filter(
            models.Asset.asset_id == location.current_asset_id
        ).first()
        if old_asset:
            old_asset.current_location_id = None
            history = models.AssetHistory(
                asset_id=old_asset.asset_id,
                old_location=location_id,
                new_location=None,
                movement_type="Replacement",
                movement_reason="Replaced by another asset",
                changed_by=changed_by,
                comments=f"Replaced by asset {asset_id}",
            )
            db.add(old_asset)
            db.add(history)

    # Unlink asset from its old location if assigned elsewhere
    if old_location_id and old_location_id != location_id:
        old_loc = db.query(models.Location).filter(
            models.Location.location_id == old_location_id
        ).first()
        if old_loc and old_loc.current_asset_id == asset_id:
            old_loc.current_asset_id = None
            db.add(old_loc)

    # Assign
    asset.current_location_id = location_id
    location.current_asset_id = asset_id

    # History record
    history = models.AssetHistory(
        asset_id=asset_id,
        old_location=old_location_id,
        new_location=location_id,
        movement_type=movement_type,
        movement_reason=movement_reason,
        changed_by=changed_by,
        comments=comments,
    )

    db.add(asset)
    db.add(location)
    db.add(history)
    db.commit()

    return {
        "message": f"Asset '{asset_id}' successfully assigned to location '{location_id}'.",
        "history_id": history.id,
    }


def unlink_asset_from_location(
    db: Session,
    asset_id: str,
    changed_by: str,
    reason: str = "Manually unlinked",
    movement_type: str = "Transfer",
) -> dict:
    """Remove an asset from its current location."""
    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not asset:
        return {"error": f"Asset '{asset_id}' not found."}
    if not asset.current_location_id:
        return {"error": f"Asset '{asset_id}' is not assigned to any location."}

    old_location_id = asset.current_location_id
    location = db.query(models.Location).filter(
        models.Location.location_id == old_location_id
    ).first()

    if location and location.current_asset_id == asset_id:
        location.current_asset_id = None
        db.add(location)

    asset.current_location_id = None

    history = models.AssetHistory(
        asset_id=asset_id,
        old_location=old_location_id,
        new_location=None,
        movement_type=movement_type,
        movement_reason=reason,
        changed_by=changed_by,
    )

    db.add(asset)
    db.add(history)
    db.commit()

    return {"message": f"Asset '{asset_id}' unlinked from location '{old_location_id}'."}
