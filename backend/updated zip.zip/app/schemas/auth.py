from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict

from .base import APIResponse
from .user import UserResponse


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    user: UserResponse


class LoginResponse(APIResponse[Token]):
    access_token: str
    token_type: str


class TokenRefresh(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


class ResetPasswordRequest(BaseModel):
    new_password: str


class SessionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    device_name: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: datetime
    expires_at: datetime
    is_revoked: bool
