from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Float,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    String,
    Table,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Permissions(Base):
    __tablename__ = "permissions"
    __table_args__ = (
        Index("ix_permissions_id", "id"),
        Index("ix_permissions_name", "name", unique=True),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[Optional[str]] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(String)

    role: Mapped[list["Roles"]] = relationship(
        "Roles", secondary="role_permissions", back_populates="permission"
    )


class Plants(Base):
    __tablename__ = "plants"
    __table_args__ = (
        Index("ix_plants_id", "id"),
        Index("ix_plants_plant_code", "plant_code", unique=True),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    plant_code: Mapped[Optional[str]] = mapped_column(String)
    plant_name: Mapped[Optional[str]] = mapped_column(String)
    address: Mapped[Optional[str]] = mapped_column(String)
    contact: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    departments: Mapped[list["Departments"]] = relationship(
        "Departments", back_populates="plant"
    )


class Roles(Base):
    __tablename__ = "roles"
    __table_args__ = (
        Index("ix_roles_id", "id"),
        Index("ix_roles_name", "name", unique=True),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[Optional[str]] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(String)

    permission: Mapped[list["Permissions"]] = relationship(
        "Permissions", secondary="role_permissions", back_populates="role"
    )


class SystemConfig(Base):
    __tablename__ = "system_config"
    __table_args__ = (
        Index("ix_system_config_id", "id"),
        Index("ix_system_config_key", "key", unique=True),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[Optional[str]] = mapped_column(String)
    value: Mapped[Optional[str]] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(String)


class Users(Base):
    __tablename__ = "users"
    __table_args__ = (
        Index("ix_users_email", "email", unique=True),
        Index("ix_users_employee_id", "employee_id", unique=True),
        Index("ix_users_id", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    employee_id: Mapped[Optional[str]] = mapped_column(String)
    name: Mapped[Optional[str]] = mapped_column(String)
    email: Mapped[Optional[str]] = mapped_column(String)
    password_hash: Mapped[Optional[str]] = mapped_column(String)
    department: Mapped[Optional[str]] = mapped_column(String)
    plant: Mapped[Optional[str]] = mapped_column(String)
    role: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    is_first_login: Mapped[Optional[bool]] = mapped_column(Boolean)
    failed_login_attempts: Mapped[Optional[int]] = mapped_column(Integer)
    last_failed_login: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    last_login_ip: Mapped[Optional[str]] = mapped_column(String)
    last_login_device: Mapped[Optional[str]] = mapped_column(String)
    last_login: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    locked_until: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    attachments: Mapped[list["Attachments"]] = relationship(
        "Attachments", back_populates="users"
    )
    audit_logs: Mapped[list["AuditLogs"]] = relationship(
        "AuditLogs", back_populates="user"
    )
    locations: Mapped[list["Locations"]] = relationship(
        "Locations", back_populates="created_by"
    )
    notifications: Mapped[list["Notifications"]] = relationship(
        "Notifications", back_populates="user"
    )
    password_history: Mapped[list["PasswordHistory"]] = relationship(
        "PasswordHistory", back_populates="user"
    )
    refresh_tokens: Mapped[list["RefreshTokens"]] = relationship(
        "RefreshTokens", back_populates="user"
    )
    inspection: Mapped[list["Inspection"]] = relationship(
        "Inspection", back_populates="inspector_"
    )
    maintenance: Mapped[list["Maintenance"]] = relationship(
        "Maintenance", back_populates="technician"
    )


class Attachments(Base):
    __tablename__ = "attachments"
    __table_args__ = (
        Index("ix_attachments_id", "id"),
        Index("ix_attachments_related_id", "related_id"),
        Index("ix_attachments_related_type", "related_type"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    related_id: Mapped[Optional[str]] = mapped_column(String)
    related_type: Mapped[Optional[str]] = mapped_column(String)
    file_path: Mapped[Optional[str]] = mapped_column(String)
    file_type: Mapped[Optional[str]] = mapped_column(String)
    label: Mapped[Optional[str]] = mapped_column(String)
    uploaded_by: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    users: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="attachments"
    )


class AuditLogs(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_logs_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    action: Mapped[Optional[str]] = mapped_column(String)
    table_name: Mapped[Optional[str]] = mapped_column(String)
    record_id: Mapped[Optional[str]] = mapped_column(String)
    old_values: Mapped[Optional[str]] = mapped_column(Text)
    new_values: Mapped[Optional[str]] = mapped_column(Text)
    ip_address: Mapped[Optional[str]] = mapped_column(String)
    device: Mapped[Optional[str]] = mapped_column(String)
    browser: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    timestamp: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    user: Mapped[Optional["Users"]] = relationship("Users", back_populates="audit_logs")


class Departments(Base):
    __tablename__ = "departments"
    __table_args__ = (
        Index("ix_departments_dept_code", "dept_code", unique=True),
        Index("ix_departments_id", "id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    dept_code: Mapped[Optional[str]] = mapped_column(String)
    dept_name: Mapped[Optional[str]] = mapped_column(String)
    plant_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("plants.id", ondelete="CASCADE")
    )
    head_name: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    plant: Mapped[Optional["Plants"]] = relationship(
        "Plants", back_populates="departments"
    )


class Locations(Base):
    __tablename__ = "locations"
    __table_args__ = (
        ForeignKeyConstraint(
            ["created_by_id"], ["users.id"], name="fk_locations_created_by_users"
        ),
        UniqueConstraint("location_name", "plant", name="uq_location_name_plant"),
        Index("ix_locations_department", "department"),
        Index("ix_locations_location_code", "location_code", unique=True),
        Index("ix_locations_location_id", "location_id"),
        Index("ix_locations_location_name", "location_name"),
        Index("ix_locations_plant", "plant"),
    )

    location_id: Mapped[str] = mapped_column(String, primary_key=True)
    location_name: Mapped[str] = mapped_column(String, nullable=False)
    qr_code: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    location_code: Mapped[Optional[str]] = mapped_column(String)
    plant: Mapped[Optional[str]] = mapped_column(String)
    area: Mapped[Optional[str]] = mapped_column(String)
    department: Mapped[Optional[str]] = mapped_column(String)
    building: Mapped[Optional[str]] = mapped_column(String)
    floor: Mapped[Optional[str]] = mapped_column(String)
    machine: Mapped[Optional[str]] = mapped_column(String)
    required_asset_type: Mapped[Optional[str]] = mapped_column(String)
    required_capacity: Mapped[Optional[str]] = mapped_column(String)
    risk_category: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    inspection_frequency: Mapped[Optional[int]] = mapped_column(Integer)
    last_inspection_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    gps_lat: Mapped[Optional[float]] = mapped_column(Float)
    gps_lng: Mapped[Optional[float]] = mapped_column(Float)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    created_by_id: Mapped[Optional[int]] = mapped_column(Integer)

    created_by: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="locations"
    )
    assets: Mapped[Optional["Assets"]] = relationship(
        "Assets", uselist=False, back_populates="location"
    )
    inspection: Mapped[list["Inspection"]] = relationship(
        "Inspection", back_populates="location"
    )
    maintenance: Mapped[list["Maintenance"]] = relationship(
        "Maintenance", back_populates="location"
    )


class Notifications(Base):
    __tablename__ = "notifications"
    __table_args__ = (Index("ix_notifications_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    type: Mapped[Optional[str]] = mapped_column(String)
    message: Mapped[Optional[str]] = mapped_column(String)
    is_read: Mapped[Optional[bool]] = mapped_column(Boolean)
    related_id: Mapped[Optional[str]] = mapped_column(String)
    related_type: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    user: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="notifications"
    )


class PasswordHistory(Base):
    __tablename__ = "password_history"
    __table_args__ = (Index("ix_password_history_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    password_hash: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    user: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="password_history"
    )


class RefreshTokens(Base):
    __tablename__ = "refresh_tokens"
    __table_args__ = (
        Index("ix_refresh_tokens_id", "id"),
        Index("ix_refresh_tokens_token_hash", "token_hash", unique=True),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token_hash: Mapped[Optional[str]] = mapped_column(String)
    user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    expires_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    device_name: Mapped[Optional[str]] = mapped_column(String)
    ip_address: Mapped[Optional[str]] = mapped_column(String)
    is_revoked: Mapped[Optional[bool]] = mapped_column(Boolean)
    revoked_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    user: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="refresh_tokens"
    )


t_role_permissions = Table(
    "role_permissions",
    Base.metadata,
    Column("role_id", ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True),
    Column(
        "permission_id",
        ForeignKey("permissions.id", ondelete="CASCADE"),
        primary_key=True,
    ),
)


class Assets(Base):
    __tablename__ = "assets"
    __table_args__ = (
        Index("ix_assets_asset_id", "asset_id"),
        Index("ix_assets_serial_number", "serial_number", unique=True),
    )

    asset_id: Mapped[str] = mapped_column(String, primary_key=True)
    serial_number: Mapped[Optional[str]] = mapped_column(String)
    asset_number: Mapped[Optional[str]] = mapped_column(String, unique=True)
    asset_type: Mapped[Optional[str]] = mapped_column(String)
    capacity: Mapped[Optional[str]] = mapped_column(String)
    manufacturer: Mapped[Optional[str]] = mapped_column(String)
    manufacturing_date: Mapped[Optional[datetime.date]] = mapped_column(Date)
    refill_date: Mapped[Optional[datetime.date]] = mapped_column(Date)
    expiry_date: Mapped[Optional[datetime.date]] = mapped_column(Date)
    amc_due_date: Mapped[Optional[datetime.date]] = mapped_column(Date)
    inspection_frequency: Mapped[Optional[int]] = mapped_column(Integer)
    barcode: Mapped[Optional[str]] = mapped_column(String)
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    photo: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    location_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("locations.location_id", ondelete="SET NULL"), unique=True
    )

    location: Mapped[Optional["Locations"]] = relationship(
        "Locations", back_populates="assets"
    )
    asset_history: Mapped[list["AssetHistory"]] = relationship(
        "AssetHistory", back_populates="asset"
    )
    inspection: Mapped[list["Inspection"]] = relationship(
        "Inspection", back_populates="asset"
    )
    maintenance: Mapped[list["Maintenance"]] = relationship(
        "Maintenance", back_populates="asset"
    )


class AssetHistory(Base):
    __tablename__ = "asset_history"
    __table_args__ = (Index("ix_asset_history_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("assets.asset_id", ondelete="CASCADE")
    )
    old_location_id: Mapped[Optional[str]] = mapped_column(String)
    new_location_id: Mapped[Optional[str]] = mapped_column(String)
    movement_type: Mapped[Optional[str]] = mapped_column(String)
    movement_reason: Mapped[Optional[str]] = mapped_column(String)
    approval_by: Mapped[Optional[str]] = mapped_column(String)
    comments: Mapped[Optional[str]] = mapped_column(Text)
    movement_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    changed_by: Mapped[Optional[str]] = mapped_column(String)

    asset: Mapped[Optional["Assets"]] = relationship(
        "Assets", back_populates="asset_history"
    )


class Inspection(Base):
    __tablename__ = "inspection"
    __table_args__ = (Index("ix_inspection_inspection_id", "inspection_id"),)

    inspection_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    location_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("locations.location_id", ondelete="CASCADE")
    )
    asset_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("assets.asset_id", ondelete="SET NULL")
    )
    inspector: Mapped[Optional[str]] = mapped_column(String)
    inspector_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    inspection_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    pressure: Mapped[Optional[str]] = mapped_column(String)
    seal: Mapped[Optional[str]] = mapped_column(String)
    hose: Mapped[Optional[str]] = mapped_column(String)
    pin: Mapped[Optional[str]] = mapped_column(String)
    gauge: Mapped[Optional[str]] = mapped_column(String)
    nozzle: Mapped[Optional[str]] = mapped_column(String)
    mounting: Mapped[Optional[str]] = mapped_column(String)
    visibility: Mapped[Optional[str]] = mapped_column(String)
    accessibility: Mapped[Optional[str]] = mapped_column(String)
    safety_tag: Mapped[Optional[str]] = mapped_column(String)
    cylinder_damage: Mapped[Optional[str]] = mapped_column(String)
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    photo: Mapped[Optional[str]] = mapped_column(String)
    overall_status: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    asset: Mapped[Optional["Assets"]] = relationship(
        "Assets", back_populates="inspection"
    )
    inspector_: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="inspection"
    )
    location: Mapped[Optional["Locations"]] = relationship(
        "Locations", back_populates="inspection"
    )
    maintenance: Mapped[list["Maintenance"]] = relationship(
        "Maintenance", back_populates="inspection"
    )


class Maintenance(Base):
    __tablename__ = "maintenance"
    __table_args__ = (Index("ix_maintenance_maintenance_id", "maintenance_id"),)

    maintenance_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("assets.asset_id", ondelete="CASCADE")
    )
    location_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("locations.location_id", ondelete="CASCADE")
    )
    issue: Mapped[Optional[str]] = mapped_column(Text)
    priority: Mapped[Optional[str]] = mapped_column(String)
    assigned_to: Mapped[Optional[str]] = mapped_column(String)
    technician_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    verified_by: Mapped[Optional[str]] = mapped_column(String)
    status: Mapped[Optional[str]] = mapped_column(String)
    opened_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    completion_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    closed_date: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    inspection_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("inspection.inspection_id", ondelete="SET NULL")
    )
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime.datetime]] = mapped_column(DateTime)

    asset: Mapped[Optional["Assets"]] = relationship(
        "Assets", back_populates="maintenance"
    )
    inspection: Mapped[Optional["Inspection"]] = relationship(
        "Inspection", back_populates="maintenance"
    )
    location: Mapped[Optional["Locations"]] = relationship(
        "Locations", back_populates="maintenance"
    )
    technician: Mapped[Optional["Users"]] = relationship(
        "Users", back_populates="maintenance"
    )
