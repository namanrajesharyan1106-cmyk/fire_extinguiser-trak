"""
FastAPI Application Entry Point — Fire Safety Asset Management System v2

Startup:
- Creates all DB tables
- Auto-creates default ADMIN user if none exists
- Serves static files for uploads
- Registers all routers with RBAC
"""

import os

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .auth import create_default_admin
from .core.config import settings
from .core.database import Base, SessionLocal, engine
from .core.logger import logger
from .routers import (
    admin,
    assets,
    auth,
    dashboard,
    inspections,
    locations,
    maintenance,
    notifications,
    reports,
    search,
)

# ─── Create all DB tables ─────────────────────────────────────────────────────
Base.metadata.create_all(bind=engine)

# ─── Ensure upload directories exist ─────────────────────────────────────────
os.makedirs(os.path.join(settings.UPLOAD_DIR, "qr"), exist_ok=True)
os.makedirs(os.path.join(settings.UPLOAD_DIR, "photos"), exist_ok=True)

# ─── FastAPI App ──────────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.APP_TITLE,
    version=settings.APP_VERSION,
    description="QR-Based Fire Safety Asset Management System for Manufacturing Plants",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Static Files (for serving uploaded images & QR codes) ───────────────────
app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")


# ─── Startup Event ────────────────────────────────────────────────────────────
@app.on_event("startup")
def startup_event():
    db = SessionLocal()
    try:
        create_default_admin(db)
    except Exception as e:
        logger.error(
            f"[STARTUP WARNING] Could not create default admin or seed db: {e}"
        )
    finally:
        db.close()


# ─── Exception Handlers ───────────────────────────────────────────────────────
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.detail,
            "data": None,
            "errors": {"status_code": exc.status_code, "path": str(request.url)},
        },
    )


@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=422,
        content={
            "success": False,
            "message": str(exc),
            "data": None,
            "errors": {"status_code": 422},
        },
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    import traceback

    logger.error(f"[ERROR] Unhandled exception: {traceback.format_exc()}")
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "message": "An internal server error occurred. Please contact support.",
            "data": None,
            "errors": {"status_code": 500},
        },
    )


# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(locations.router, prefix="/api/locations", tags=["Locations"])
app.include_router(assets.router, prefix="/api/assets", tags=["Assets"])
app.include_router(inspections.router, prefix="/api/inspections", tags=["Inspections"])
app.include_router(maintenance.router, prefix="/api/maintenance", tags=["Maintenance"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard"])
app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])
app.include_router(admin.router, prefix="/api/admin", tags=["Admin"])
app.include_router(
    notifications.router, prefix="/api/notifications", tags=["Notifications"]
)
app.include_router(search.router, prefix="/api/search", tags=["Search"])


# ─── Health Check ─────────────────────────────────────────────────────────────
@app.get("/")
def read_root():
    return {
        "success": True,
        "message": f"Welcome to {settings.APP_TITLE}",
        "data": {
            "version": settings.APP_VERSION,
            "docs": "/docs",
            "status": "running",
        },
        "errors": None,
    }


@app.get("/health")
def health_check():
    return {"status": "healthy", "version": settings.APP_VERSION}
