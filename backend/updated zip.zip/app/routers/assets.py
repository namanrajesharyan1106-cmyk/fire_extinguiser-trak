"""
Assets router — CRUD, assignment validation, history, photo upload.
"""

import os
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import settings
from ..core import database
from ..core import dependencies as auth
from ..services.asset_service import (
    perform_asset_assignment,
    unlink_asset_from_location,
    validate_asset_assignment,
)
from ..utils import create_audit_log, model_to_dict

router = APIRouter()


@router.get("/", response_model=List[schemas.AssetResponse])
def get_assets(
    skip: int = 0,
    limit: int = 200,
    asset_type: Optional[str] = None,
    status: Optional[str] = None,
    unassigned_only: bool = False,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("view_assets")),
):
    query = db.query(models.Asset)
    if asset_type:
        query = query.filter(models.Asset.asset_type == asset_type)
    if status:
        query = query.filter(models.Asset.status == status)
    if unassigned_only:
        query = query.filter(models.Asset.location_id.is_(None))
    return query.order_by(models.Asset.asset_id).offset(skip).limit(limit).all()


@router.get("/{asset_id}", response_model=schemas.AssetResponse)
def get_asset(
    asset_id: str,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("view_assets")),
):
    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    return asset


@router.post("/", response_model=schemas.AssetResponse, status_code=201)
def create_asset(
    asset: schemas.AssetCreate,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("create_asset")),
):
    import uuid

    # Auto-generate asset_id if not provided by client
    asset_id = asset.asset_id or f"AST-{uuid.uuid4().hex[:8].upper()}"

    existing = (
        db.query(models.Asset)
        .filter(
            (models.Asset.asset_id == asset_id)
            | (models.Asset.serial_number == asset.serial_number)
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=400, detail="Asset ID or Serial Number already registered"
        )

    asset_data = asset.model_dump(exclude={"asset_id"})
    new_asset = models.Asset(**asset_data, asset_id=asset_id)
    new_asset.created_at = datetime.utcnow()
    new_asset.updated_at = datetime.utcnow()
    db.add(new_asset)
    db.commit()
    db.refresh(new_asset)

    create_audit_log(db, current_user.id, "CREATE", "assets", asset_id)
    db.commit()
    return new_asset


@router.put("/{asset_id}", response_model=schemas.AssetResponse)
def update_asset(
    asset_id: str,
    asset: schemas.AssetUpdate,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("edit_asset")),
):
    db_asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not db_asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    old_values = model_to_dict(db_asset)
    for key, value in asset.model_dump(exclude_unset=True).items():
        setattr(db_asset, key, value)
    db_asset.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(db_asset)

    create_audit_log(
        db,
        current_user.id,
        "UPDATE",
        "assets",
        asset_id,
        old_values=old_values,
        new_values=model_to_dict(db_asset),
    )
    db.commit()
    return db_asset


@router.delete("/{asset_id}")
def delete_asset(
    asset_id: str,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("delete_asset")),
):
    db_asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not db_asset:
        raise HTTPException(status_code=404, detail="Asset not found")
    if db_asset.current_location_id:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete assigned asset '{asset_id}'. Unlink from location '{db_asset.current_location_id}' first.",
        )

    db.delete(db_asset)
    db.commit()
    create_audit_log(db, current_user.id, "DELETE", "assets", asset_id)
    db.commit()
    return {"message": f"Asset '{asset_id}' deleted successfully"}


# ─── Assignment Endpoints ────────────────────────────────────────────────────
@router.post("/{asset_id}/link/{location_id}")
def link_asset_to_location(
    asset_id: str,
    location_id: str,
    payload: Optional[schemas.AssetAssignRequest] = None,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("assign_asset")),
):
    """
    Assign asset to location with full validation.
    Raises detailed errors for mismatches, expired status, open tickets, etc.
    """
    if payload is None:
        payload = schemas.AssetAssignRequest()

    can_assign, errors, warnings = validate_asset_assignment(
        db, asset_id, location_id, force=payload.force
    )

    if not can_assign:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Asset assignment validation failed",
                "errors": errors,
                "warnings": warnings,
            },
        )

    result = perform_asset_assignment(
        db=db,
        asset_id=asset_id,
        location_id=location_id,
        changed_by=current_user.email,
        movement_type=payload.movement_type,
        movement_reason=payload.movement_reason,
        comments=payload.comments,
    )

    create_audit_log(
        db,
        current_user.id,
        "ASSIGN",
        "assets",
        asset_id,
        new_values={"location": location_id},
    )
    db.commit()

    return {**result, "warnings": warnings}


@router.delete("/{asset_id}/unlink")
def unlink_asset(
    asset_id: str,
    reason: str = "Manually unlinked",
    movement_type: str = "Transfer",
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("assign_asset")),
):
    result = unlink_asset_from_location(
        db, asset_id, current_user.email, reason, movement_type
    )
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])

    create_audit_log(db, current_user.id, "UNLINK", "assets", asset_id)
    db.commit()
    return result


@router.get("/{asset_id}/history", response_model=List[schemas.AssetHistoryResponse])
def get_asset_history(
    asset_id: str,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("view_assets")),
):
    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    return (
        db.query(models.AssetHistory)
        .filter(models.AssetHistory.asset_id == asset_id)
        .order_by(models.AssetHistory.movement_date.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.post("/{asset_id}/photo")
async def upload_asset_photo(
    asset_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(database.get_db),
    current_user: models.User = Depends(auth.require_permission("edit_asset")),
):
    asset = db.query(models.Asset).filter(models.Asset.asset_id == asset_id).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type '{ext}'. Allowed: {list(settings.ALLOWED_EXTENSIONS)}",
        )

    # Check size
    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail=f"File exceeds {settings.MAX_UPLOAD_SIZE_MB}MB limit",
        )

    filename = f"asset_{asset_id}{ext}"
    save_path = os.path.join(settings.UPLOAD_DIR, "photos", filename)
    with open(save_path, "wb") as f:
        f.write(content)

    asset.photo = f"uploads/photos/{filename}"
    db.commit()
    return {"photo_url": asset.photo, "message": "Photo uploaded successfully"}
