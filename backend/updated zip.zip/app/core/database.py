from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from .config import settings

# For synchronous operations (if needed, but usually we prefer async for FastAPI, though existing code is sync)
engine = create_engine(
    settings.get_database_url,
    connect_args=(
        {"check_same_thread": False} if "sqlite" in settings.get_database_url else {}
    ),
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """
    Synchronous dependency to get DB session
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
